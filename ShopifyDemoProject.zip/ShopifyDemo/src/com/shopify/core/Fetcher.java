package com.shopify.core;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shopify.model.Product;
import com.shopify.model.StorePrivateApp;

public class Fetcher {



	public static void main(String[] args) throws Exception {

		// created a store object with all parameters
		StorePrivateApp storeInfo = new StorePrivateApp("ea27711415f294a8767e517a6be9c1cb", "3b651252e2bc6fea97872916cd1a7c3f","ashish-store-integration.myshopify.com");
		
		String formedQuery = getQueryFromParameters(storeInfo, 3, 2);
		
		System.out.println(formedQuery);
		
		HttpClient client = new DefaultHttpClient();
		
		HttpGet request = new HttpGet(formedQuery);
		
		HttpResponse httpResponse = client.execute(request);
		
		// here checkin the response for any error, if error is there in API response then exception would be thrown frm the method.
		Map<String,Object> response = checkResponseForError(httpResponse);
		
		List<Product> products = (List<Product>) response.get("products");
		System.out.println(products);
		
	}
	
	static Map<String,Object> checkResponseForError(HttpResponse httpResponse) throws Exception {
		int statusCode = httpResponse.getStatusLine().getStatusCode();
		BufferedReader rd = new BufferedReader (new InputStreamReader(httpResponse.getEntity().getContent()));
		StringBuilder response = new StringBuilder("");
		String line = "";
		while (( line = rd.readLine()) != null) {
			response.append(line);
		}
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String,Object> responseMap = mapper.readValue(response.toString(),  new TypeReference<HashMap<String,Object>>(){});

		if(statusCode!=200) {			
			String errorMessage = (String) responseMap.get("errors");
			// here custom exception could have been thrown
			throw new Exception("Unable to fetch List of products, received error : " + errorMessage);
		}
		return responseMap;
	}

	/**
	 * 
	 * @param storeInfo
	 * @param pageSize
	 * @param pageNumber
	 * @return URL for querying particular page of products
	 */
	static String getQueryFromParameters(StorePrivateApp storeInfo, int pageSize, int pageNumber) {
		StringBuilder queryURL = new StringBuilder("https://");
		queryURL.append(storeInfo.getUserName()).append(":");
		queryURL.append(storeInfo.getPassword()).append("@");
		queryURL.append(storeInfo.getStoreURL());
		queryURL.append("/admin/products.json?limit=").append(pageSize)
		.append("&page=").append(pageNumber);
		
		return queryURL.toString();
	}
	
	
}
