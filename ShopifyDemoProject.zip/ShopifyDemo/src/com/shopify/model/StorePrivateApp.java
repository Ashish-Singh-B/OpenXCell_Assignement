package com.shopify.model;

public class StorePrivateApp {
	String userName;
	String password;
	String storeURL;
	
	
	public StorePrivateApp(String userName, String password, String storeURL) {
		super();
		this.userName = userName;
		this.password = password;
		this.storeURL = storeURL;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStoreURL() {
		return storeURL;
	}
	public void setStoreURL(String storeURL) {
		this.storeURL = storeURL;
	}
	
	
}
